/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;
import javax.swing.JTextArea;
/**
 *
 * @author coter
 */
public class Traza {
    private final JTextArea area;
    private int evaluaciones, descartes, aceptaciones;

    public Traza(JTextArea area) { 
        this.area = area; 
    }
    
    public int getEvaluaciones() { 
        return evaluaciones; 
    }
    public int getDescartes()    { 
        return descartes; 
    }
    public int getAceptaciones() { 
        return aceptaciones; 
    }

    public void titulo(String s) { 
        escribir("\n=== " + s + " ===\n"); 
    }
    public void linea(String s)  { 
        escribir("  " + s + "\n"); 
    }
    public void visita(String s) { 
        escribir("  [VISITA]   " + s + "\n"); 
    }
    public void evaluar() { 
        evaluaciones++; 
    }

    public void acepta(String s) {
        aceptaciones++;
        escribir("  [ACEPTA]   " + s + "\n");
    }

    public void descarta(String s) {
        descartes++;
        escribir("  [DESCARTA] " + s + "\n");
    }
    
    public void construye(String s) {
        escribir("  [CONSTRUYE] " + s + "\n");
    }

    public void reiniciarContadores() { 
        evaluaciones = descartes = aceptaciones = 0; 
    }

    private void escribir(String s) {
        area.append(s);
        area.setCaretPosition(area.getDocument().getLength()); // autoscroll
    }
}//Final

/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author coter
 */
public class ResultadoRutas {
    private final List<String> ruta;
    private final int costo;
    private final String algoritmo;
    private final long tiempoMs;
    private final int evaluaciones, aceptaciones, descartes;

    public ResultadoRutas(List<String> ruta, int costo, String algoritmo, long tiempoMs, int evaluaciones, int aceptaciones, int descartes) {
        this.ruta = new ArrayList<>(ruta);
        this.costo = costo;
        this.algoritmo = algoritmo;
        this.tiempoMs = tiempoMs;
        this.evaluaciones = evaluaciones;
        this.aceptaciones = aceptaciones;
        this.descartes = descartes;
    }

    public List<String> getRuta() { 
        return new ArrayList<>(ruta); 
    }
    public int getCosto() { 
        return costo; 
    }
    public String getAlgoritmo() { 
        return algoritmo; 
    }
    public long getTiempoMs() { 
        return tiempoMs; 
    }
    public int getEvaluaciones() { 
        return evaluaciones; 
    }
    public int getAceptaciones() { 
        return aceptaciones; 
    }
    public int getDescartes() { 
        return descartes; 
    }

    public String getRutaComoTexto() { 
        return String.join(" -> ", ruta); 
    }
}//final

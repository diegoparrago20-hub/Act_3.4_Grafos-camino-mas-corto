/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
/**
 *
 * @author coter
 */
public class Rutas {
    private static final int INF = Integer.MAX_VALUE;
    private final GrafoPonderado grafo;

    public Rutas(GrafoPonderado grafo) { this.grafo = grafo; }

// Para el algoritmo de DIJKSTRA 
    public ResultadoRutas dijkstra(String origen, String destino, Traza t) {
        long inicio = System.nanoTime();

        Map<String, Integer> dist = new HashMap<>();
        Map<String, String> prev = new HashMap<>();
        Set<String> visitados = new HashSet<>();

        t.titulo("DIJKSTRA: " + origen + " -> " + destino);
        t.linea("Fase de inicialización:");
        for (String id : grafo.getIdsVertices()) {
            dist.put(id, INF);
            prev.put(id, null);
            t.linea("dist[" + id + "] = " + (id.equals(origen) ? "0" : "∞"));
        }
        dist.put(origen, 0);

        PriorityQueue<String> cola = new PriorityQueue<>(Comparator.comparingInt(dist::get));
        cola.add(origen);

        while (!cola.isEmpty()) {
            String u = cola.poll();
            if (visitados.contains(u)) continue;   // entrada obsoleta
            visitados.add(u);
            t.visita("Extraído: " + u + " (dist = " + dist.get(u) + ")");

            if (u.equals(destino)) {
                t.linea("Destino alcanzado; se detiene la búsqueda.");
                break;
            }

            for (Arista a : grafo.getAdyacentes(u)) {
                String v = a.getDestino();

                if (visitados.contains(v)) {
                    t.descarta(u + "->" + v + ": " + v + " ya fue visitado (dist = "
                            + dist.get(v) + ")");
                    continue;
                }

                t.evaluar();
                int acumulado = dist.get(u) + (int) a.getPeso();

                if (acumulado < dist.get(v)) {
                    int anterior = dist.get(v);
                    dist.put(v, acumulado);
                    prev.put(v, u);
                    cola.add(v);
                    t.acepta(u + "->" + v + ": " + dist.get(u) + " + " + (int) a.getPeso()
                            + " = " + acumulado + " < " + (anterior == INF ? "∞" : anterior)
                            + "  => dist[" + v + "] = " + acumulado);
                } else {
                    t.descarta(u + "->" + v + ": " + dist.get(u) + " + " + (int) a.getPeso()
                            + " = " + acumulado + " >= " + dist.get(v)
                            + "  => se conserva dist[" + v + "] = " + dist.get(v));
                }
            }
        }

        long ms = (System.nanoTime() - inicio) / 1_000_000;
        return construirResultado(dist, prev, origen, destino, "Dijkstra", ms, t);
    }

// Para el algoritmo de BELLMAN-FORD 
    public ResultadoRutas bellmanFord(String origen, String destino, Traza t) {
        long inicio = System.nanoTime();

        Map<String, Integer> dist = new HashMap<>();
        Map<String, String> prev = new HashMap<>();
        List<Arista> aristas = grafo.getAristas();
        int n = grafo.getNumVertices();

        t.titulo("BELLMAN-FORD: " + origen + " -> " + destino);
        t.linea("Fase de inicialización:");
        for (String id : grafo.getIdsVertices()) {
            dist.put(id, INF);
            prev.put(id, null);
            t.linea("dist[" + id + "] = " + (id.equals(origen) ? "0" : "∞"));
        }
        dist.put(origen, 0);

        for (int i = 1; i <= n - 1; i++) {
            boolean huboCambio = false;
            t.titulo("Iteración " + i + " de " + (n - 1));

            for (Arista a : aristas) {
                String u = a.getOrigen(), v = a.getDestino();

                t.evaluar();
                if (dist.get(u) == INF) {
                    t.descarta(u + "->" + v + ": " + u + " aún es inalcanzable (∞)");
                    continue;
                }

                t.evaluar();
                int acumulado = dist.get(u) + (int) a.getPeso();

                if (acumulado < dist.get(v)) {
                    int anterior = dist.get(v);
                    dist.put(v, acumulado);
                    prev.put(v, u);
                    huboCambio = true;
                    t.acepta(u + "->" + v + ": " + dist.get(u) + " + " + (int) a.getPeso()
                            + " = " + acumulado + " < " + (anterior == INF ? "∞" : anterior)
                            + "  => dist[" + v + "] = " + acumulado);
                } else {
                    t.descarta(u + "->" + v + ": " + dist.get(u) + " + " + (int) a.getPeso()
                            + " = " + acumulado + " >= " + dist.get(v)
                            + "  => se conserva dist[" + v + "] = " + dist.get(v));
                }
            }

            if (!huboCambio) {
                t.linea("Sin cambios en esta iteración: convergencia alcanzada, se corta");
                break;
            }
        }

        // Pasada de verificación de ciclos negativos
        for (Arista a : aristas) {
            String u = a.getOrigen(), v = a.getDestino();
            if (dist.get(u) != INF && dist.get(u) + (int) a.getPeso() < dist.get(v)) {
                t.titulo("CICLO NEGATIVO DETECTADO");
                t.linea("La arista " + u + "->" + v + " aún puede relajarse.");
                t.linea("No existe una ruta óptima bien definida.");
                return null;
            }
        }

        long ms = (System.nanoTime() - inicio) / 1_000_000;
        return construirResultado(dist, prev, origen, destino, "Bellman-Ford", ms, t);
    }

// Para hacer la comparativa
    public void comparar(String origen, String destino, Traza t) {
        t.titulo("EJECUCIÓN COMPARATIVA");

        t.titulo("--- Algoritmo 1: Dijkstra ---");
        t.reiniciarContadores();
        ResultadoRutas r1 = dijkstra(origen, destino, t);
        int ev1 = t.getEvaluaciones(), ac1 = t.getAceptaciones(), de1 = t.getDescartes();

        t.titulo("--- Algoritmo 2: Bellman-Ford ---");
        t.reiniciarContadores();
        ResultadoRutas r2 = bellmanFord(origen, destino, t);
        int ev2 = t.getEvaluaciones(), ac2 = t.getAceptaciones(), de2 = t.getDescartes();

        t.titulo("TABLA COMPARATIVA");
        t.linea(String.format("%-14s %-8s %-13s %-13s %-10s %s",
                "Algoritmo", "Costo", "Evaluaciones", "Aceptaciones", "Descartes", "Tiempo"));
        t.linea(String.format("%-14s %-8s %-13d %-13d %-10d %d ms",
                "Dijkstra", r1 == null ? "-" : r1.getCosto(), ev1, ac1, de1,
                r1 == null ? 0 : r1.getTiempoMs()));
        t.linea(String.format("%-14s %-8s %-13d %-13d %-10d %d ms",
                "Bellman-Ford", r2 == null ? "-" : r2.getCosto(), ev2, ac2, de2,
                r2 == null ? 0 : r2.getTiempoMs()));

        if (r1 != null && r2 != null) {
            boolean iguales = r1.getCosto() == r2.getCosto();
            t.linea("Coinciden en el costo óptimo: " + (iguales ? "SÍ" : "NO"));
            t.linea("Ruta Dijkstra:      " + r1.getRutaComoTexto());
            t.linea("Ruta Bellman-Ford:  " + r2.getRutaComoTexto());
        } else {
            t.linea("No fue posible comparar: alguna ejecución no produjo ruta");
        }
    }

// Reconstruccion del camino
    private ResultadoRutas construirResultado(Map<String, Integer> dist, Map<String, String> prev, String origen, String destino, String algoritmo, long ms, Traza t) {
        t.titulo("RESULTADO FINAL");

        if (dist.get(destino) == null || dist.get(destino) == INF) {
            t.linea("No existe camino entre " + origen + " y " + destino
                    + " (nodo inalcanzable).");
            return null;
        }

        LinkedList<String> ruta = new LinkedList<>();
        for (String v = destino; v != null; v = prev.get(v)) ruta.addFirst(v);

        t.linea("Secuencia: " + String.join(" -> ", ruta));
        t.linea("Costo total: " + dist.get(destino));
        t.linea("Evaluaciones: " + t.getEvaluaciones() + " | Aceptaciones: " + t.getAceptaciones()
                + " | Descartes: " + t.getDescartes() + " | Tiempo: " + ms + " ms");

        return new ResultadoRutas(new ArrayList<>(ruta), dist.get(destino), algoritmo,
                ms, t.getEvaluaciones(), t.getAceptaciones(), t.getDescartes());
    }
}//Final

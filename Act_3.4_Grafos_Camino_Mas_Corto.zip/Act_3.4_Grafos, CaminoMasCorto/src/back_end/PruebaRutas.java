/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;
//// En base de la insertidumbre de si debia tambien crear el grafo la ventana hicimos esta clase
/**
 *
 * @author coter
 */
import javax.swing.JTextArea;

public class PruebaRutas {

    public static GrafoPonderado grafoDemo() {
        GrafoPonderado g = new GrafoPonderado();
        g.crearGrafo(true);

        g.agregarVertice("A", "Bodega Central",  "Almacen", "Activo", 500);
        g.agregarVertice("B", "Sucursal Norte",  "Sucursal", "Activo", 200);
        g.agregarVertice("C", "Sucursal Centro", "Sucursal", "Activo", 300);
        g.agregarVertice("D", "Sucursal Sur",    "Sucursal", "Activo", 150);
        g.agregarVertice("E", "Centro Dist.",    "Almacen",  "Activo", 400);
        g.agregarVertice("F", "Punto Entrega",   "Entrega",  "Activo", 50);
        g.agregarVertice("G", "Centro de Entrega", "Entrega", "Activo", 100); // aislado, para el caso de inaccesibilidad
        g.agregarVertice("P", "Centro de Entrega", "Entrega", "Activo", 100);
        
        g.agregarArista("A", "B", 4);
        g.agregarArista("A", "D", 2);
        g.agregarArista("B", "C", 3);
        g.agregarArista("B", "E", 9);   // se descarta contra A->D->C->E
        g.agregarArista("C", "E", 2);
        g.agregarArista("C", "F", 7);
        g.agregarArista("D", "C", 5);
        g.agregarArista("E", "F", 1);
        g.agregarArista("P", "F", 2);
        g.agregarArista("C", "P", 6);
        return g;
    }
    
    public static GrafoPonderado grafoConPesoNegativo() {
        GrafoPonderado g = grafoDemo();
        g.agregarVertice("W", "Cede principal", "Sucursales", "Activo", 150);
        g.agregarArista("E", "W", -5);
        return g;
    }

    public static void main(String[] args) {
        GrafoPonderado g = grafoDemo();
        Rutas rc = new Rutas(g);
        JTextArea area = new JTextArea();
        Traza t = new Traza(area);

        rc.dijkstra("A", "F", t);
        rc.bellmanFord("A", "F", t);
        rc.comparar("A", "F", t);

        System.out.println(area.getText());
    }
}//Final